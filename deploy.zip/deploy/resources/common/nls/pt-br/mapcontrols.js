define({
  "commonMapControls": {
    "common": {
      "settings": "Configurações",
      "openDefault": "Abrir por padrão"
    },
    "overview": {
      "basemapGalleryBtnLabel": "Mapa Base",
      "expandFactorLabel": "Expandir Fator",
      "expandFactorPopover": "A relação entre o tamanho do mapa de visão geral e o retângulo de extensão exibido no mapa de visão geral. O valor padrão é 2, ou seja, o mapa de visão geral será pelo menos o dobro do tamanho do retângulo de extensão."
    }
  }
});