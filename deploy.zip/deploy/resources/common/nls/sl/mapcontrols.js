define({
  "commonMapControls": {
    "common": {
      "settings": "Nastavitve",
      "openDefault": "Privzeto odpri"
    },
    "overview": {
      "basemapGalleryBtnLabel": "Temeljna karta",
      "expandFactorLabel": "Razširitveni dejavnik",
      "expandFactorPopover": "Razmerje med velikostjo pregledne karte in obsega pravokotnika, prikazanega na pregledni karti. Privzeta vrednost je 2, kar pomeni, da je pregledna karta najmanj dvakrat večja od obsega pravokotnika."
    }
  }
});