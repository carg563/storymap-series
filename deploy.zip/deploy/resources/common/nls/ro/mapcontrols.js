define({
  "commonMapControls": {
    "common": {
      "settings": "Setări",
      "openDefault": "Deschidere implicită"
    },
    "overview": {
      "basemapGalleryBtnLabel": "Hartă fundal",
      "expandFactorLabel": "Factor de extindere",
      "expandFactorPopover": "Raportul dintre dimensiunea hărţii de prezentare generală şi dreptunghiul existent afişat în harta de prezentare generală. Valoarea implicită este 2, ceea ce înseamnă că harta de prezentare generală va fi de cel puţin două ori mai mar decât dreptunghiul extinderii."
    }
  }
});