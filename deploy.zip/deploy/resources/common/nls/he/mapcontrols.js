define({
  "commonMapControls": {
    "common": {
      "settings": "הגדרות",
      "openDefault": "פתוח כברירת מחדל"
    },
    "overview": {
      "basemapGalleryBtnLabel": "מפת בסיס",
      "expandFactorLabel": "פקטור הרחבה",
      "expandFactorPopover": "היחס בין גודל מפת ההתמצאות ומלבן התיחום מוצג במפת ההתמצאות. ערך ברירת המחדל הוא 2 ומשמעותו, מפת ההתמצאות תהיה לפחות פי שנים מגודל מלבן התיחום."
    }
  }
});